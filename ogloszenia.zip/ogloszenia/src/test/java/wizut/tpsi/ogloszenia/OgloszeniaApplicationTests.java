package wizut.tpsi.ogloszenia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OgloszeniaApplicationTests {

	@Test
	void contextLoads() {
	}

}
